package Model;

public class Collector {

}
