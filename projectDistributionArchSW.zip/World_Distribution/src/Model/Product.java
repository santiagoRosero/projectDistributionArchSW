package Model;

public class Product {
	
	public final static String TYPE_A="typeA";
	public final static String TYPE_B="typeB";
	public final static double VOLUME_A=10;
	public final static double VOLUME_B=15;

	private String type;
	private double volume;
}
