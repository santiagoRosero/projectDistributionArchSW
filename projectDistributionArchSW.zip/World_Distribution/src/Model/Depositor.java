package Model;

public class Depositor {

}
